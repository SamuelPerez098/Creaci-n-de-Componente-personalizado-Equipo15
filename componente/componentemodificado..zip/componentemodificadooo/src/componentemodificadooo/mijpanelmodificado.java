/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package componentemodificadooo;

/**
 *
 * @author gabym
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.awt.image.BufferedImage;
public class mijpanelmodificado extends javax.swing.JPanel {
    
    
    private JLabel imageLabel;
    private final List<ImageIcon> images = new ArrayList<>();
    private int currentIndex = 0;
    private JScrollPane imageScrollPane;
    private double zoomFactor = 1.0;
    private JButton btnIzquierda, btnDerecha;
    private JPanel galleryPanel;
    private JScrollPane galleryScrollPane;
    private final int MAX_IMAGENES = 20;

    private String RUTA_PREDETERMINADA = "C:\\\\\\\\Users\\\\\\\\gabym\\\\\\\\OneDrive\\\\\\\\Documents\\\\\\\\NetBeansProjects\\\\\\\\componentemodificadooo\\\\\\\\imagenesijijij";

    public mijpanelmodificado() {
        setLayout(new BorderLayout());

        // Menú contextual
        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem seleccionarItem = new JMenuItem("Seleccionar imágenes");
        seleccionarItem.addActionListener(e -> seleccionarImagenes());

        JMenuItem carpetaItem = new JMenuItem("Cargar carpeta");
        carpetaItem.addActionListener(e -> seleccionarCarpeta());

        JMenuItem rotarItem = new JMenuItem("Rotar imagen");
        rotarItem.addActionListener(e -> rotateImage());

        JMenuItem eliminarItem = new JMenuItem("Eliminar imagen");
        eliminarItem.addActionListener(e -> deleteImage());

        popupMenu.add(seleccionarItem);
        popupMenu.add(carpetaItem);
        popupMenu.add(rotarItem);
        popupMenu.add(eliminarItem);

        MouseAdapter popupListener = new MouseAdapter() {
            private void showPopup(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    popupMenu.show(e.getComponent(), e.getX(), e.getY());
                }
            }

            public void mousePressed(MouseEvent e) { showPopup(e); }
            public void mouseReleased(MouseEvent e) { showPopup(e); }
        };

        imageLabel = new JLabel("", JLabel.CENTER);
        imageScrollPane = new JScrollPane(imageLabel);
        this.add(imageScrollPane, BorderLayout.CENTER);

        this.addMouseListener(popupListener);
        imageLabel.addMouseListener(popupListener);
        imageScrollPane.addMouseListener(popupListener);

        imageLabel.addMouseWheelListener(e -> zoomImage(e.getWheelRotation()));

        btnIzquierda = new JButton("⯇");
        btnDerecha = new JButton("⯈");

        configurarBotonInvisible(btnIzquierda);
        configurarBotonInvisible(btnDerecha);

        this.add(btnIzquierda, BorderLayout.WEST);
        this.add(btnDerecha, BorderLayout.EAST);

        btnIzquierda.addActionListener(e -> showPreviousImage());
        btnDerecha.addActionListener(e -> showNextImage());

        MouseMotionAdapter movimientoMouse = new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                Point point = SwingUtilities.convertPoint(e.getComponent(), e.getPoint(), mijpanelmodificado.this);
                int x = point.x;
                int margin = 40;

                btnIzquierda.setVisible(x < margin);
                btnDerecha.setVisible(x > getWidth() - margin);
            }
        };

        this.addMouseMotionListener(movimientoMouse);
        imageLabel.addMouseMotionListener(movimientoMouse);
        imageScrollPane.addMouseMotionListener(movimientoMouse);

        addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                displayImage();
            }
        });

        // Tira de miniaturas horizontal
        galleryPanel = new JPanel();
        galleryPanel.setLayout(new BoxLayout(galleryPanel, BoxLayout.X_AXIS));
        galleryScrollPane = new JScrollPane(galleryPanel);
        galleryScrollPane.setPreferredSize(new Dimension(100, 100));
        galleryScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        galleryScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        this.add(galleryScrollPane, BorderLayout.SOUTH);

        // Carga automática desde la ruta fija
        precargarImagenes(RUTA_PREDETERMINADA);
    }

    private void configurarBotonInvisible(JButton button) {
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setVisible(false);
    }

    private void seleccionarImagenes() {
        JFileChooser chooser = new JFileChooser();
        chooser.setMultiSelectionEnabled(true);
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File[] selectedFiles = chooser.getSelectedFiles();

            int count = 0;
            for (File file : selectedFiles) {
                if (esImagen(file) && count < MAX_IMAGENES) {
                    images.add(new ImageIcon(file.getAbsolutePath()));
                    count++;
                }
            }

            if (images.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No se seleccionaron imágenes válidas.");
            } else {
                currentIndex = images.size() - count; // Ir al inicio de las nuevas
                zoomFactor = 1.0;
                displayImage();
                updateGallery();
            }
        }
    }

    private void seleccionarCarpeta() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File carpeta = chooser.getSelectedFile();
            precargarImagenes(carpeta.getAbsolutePath());
        }
    }

    private void precargarImagenes(String ruta) {
        File folder = new File(ruta);
        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles((dir, name) ->
                    name.toLowerCase().endsWith(".jpg") ||
                    name.toLowerCase().endsWith(".jpeg") ||
                    name.toLowerCase().endsWith(".png") ||
                    name.toLowerCase().endsWith(".gif")
            );

            if (files != null && files.length > 0) {
                Arrays.sort(files, Comparator.comparing(File::getName));
                images.clear();
                for (int i = 0; i < Math.min(files.length, MAX_IMAGENES); i++) {
                    images.add(new ImageIcon(files[i].getAbsolutePath()));
                }
                currentIndex = 0;
                zoomFactor = 1.0;
                displayImage();
                updateGallery();
            }
        }
    }

    private boolean esImagen(File file) {
        String name = file.getName().toLowerCase();
        return name.endsWith(".jpg") || name.endsWith(".jpeg") ||
               name.endsWith(".png") || name.endsWith(".gif");
    }

    private void displayImage() {
        if (!images.isEmpty() && currentIndex >= 0 && currentIndex < images.size()) {
            ImageIcon originalIcon = images.get(currentIndex);
            Image originalImage = originalIcon.getImage();

            int imgWidth = (int) (originalIcon.getIconWidth() * zoomFactor);
            int imgHeight = (int) (originalIcon.getIconHeight() * zoomFactor);

            Image scaledImage = originalImage.getScaledInstance(imgWidth, imgHeight, Image.SCALE_SMOOTH);
            imageLabel.setIcon(new ImageIcon(scaledImage));
            imageLabel.setPreferredSize(new Dimension(imgWidth, imgHeight));
            imageLabel.revalidate();
        } else {
            imageLabel.setIcon(null);
        }
    }

    private void showPreviousImage() {
        if (currentIndex > 0) {
            currentIndex--;
            zoomFactor = 1.0;
            displayImage();
        }
    }

    private void showNextImage() {
        if (currentIndex < images.size() - 1) {
            currentIndex++;
            zoomFactor = 1.0;
            displayImage();
        }
    }

    private void rotateImage() {
        if (!images.isEmpty()) {
            ImageIcon icon = images.get(currentIndex);
            Image image = icon.getImage();
            int w = icon.getIconWidth();
            int h = icon.getIconHeight();

            BufferedImage rotated = new BufferedImage(h, w, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = rotated.createGraphics();
            g2d.translate(h / 2, w / 2);
            g2d.rotate(Math.toRadians(90));
            g2d.translate(-w / 2, -h / 2);
            g2d.drawImage(image, 0, 0, null);
            g2d.dispose();

            images.set(currentIndex, new ImageIcon(rotated));
            displayImage();
        }
    }

    private void deleteImage() {
        if (!images.isEmpty()) {
            images.remove(currentIndex);
            if (currentIndex >= images.size()) {
                currentIndex = images.size() - 1;
            }
            displayImage();
            updateGallery();
        }
    }

    private void zoomImage(int wheelRotation) {
        if (!images.isEmpty()) {
            zoomFactor += (wheelRotation < 0) ? 0.1 : -0.1;
            zoomFactor = Math.max(0.1, Math.min(zoomFactor, 5.0));
            displayImage();
        }
    }

    private void updateGallery() {
        galleryPanel.removeAll();
        for (int i = 0; i < images.size(); i++) {
            final int index = i;
            ImageIcon icon = new ImageIcon(images.get(i).getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH));
            JLabel thumbLabel = new JLabel(icon);
            thumbLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
            thumbLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            thumbLabel.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    currentIndex = index;
                    zoomFactor = 1.0;
                    displayImage();
                }
            });
            galleryPanel.add(thumbLabel);
        }
        galleryPanel.revalidate();
        galleryPanel.repaint();
    }

    // === MÉTODOS PARA EDITOR VISUAL ===

    public String getRutaImagenes() {
        return this.RUTA_PREDETERMINADA;
    }

    public void setRutaImagenes(String ruta) {
        this.RUTA_PREDETERMINADA = ruta;
        precargarImagenes(ruta);
    }

    public int getIndiceImagenActual() {
        return this.currentIndex;
    }

    public void setIndiceImagenActual(int indice) {
        if (indice >= 0 && indice < images.size()) {
            this.currentIndex = indice;
            displayImage();
        }
    }

    @Override
    public void setBackground(Color color) {
        super.setBackground(color);
        if (imageLabel != null) {
            imageLabel.setBackground(color);
            imageLabel.setOpaque(true);
        }
    }

    public double getZoomInicial() {
        return this.zoomFactor;
    }

    public void setZoomInicial(double zoom) {
        this.zoomFactor = Math.max(0.1, Math.min(zoom, 5.0));
        displayImage();
    }
    
}
